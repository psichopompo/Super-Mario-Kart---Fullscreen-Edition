# Super Mario Kart – Fullscreen Edition (USA)

Un hack que convierte la vista de carrera de **1 jugador de Super Mario Kart** en una pantalla completa de verdad.

La pista ocupa las **256×224 píxeles** disponibles, la cámara se acerca al kart y todo lo que dependía de la distribución original —HUD, textos, efectos, objetos, colisiones y demás elementos de pantalla— se adapta a la nueva perspectiva.

Hecho por **Psicopompo**.

## Por qué existe

Super Mario Kart reserva en 1 jugador una parte de la pantalla para el mapa y el retrovisor, como consecuencia del diseño a pantalla partida del modo 2P.

Eliminar esa zona parece sencillo, pero en realidad es sólo el principio. Si simplemente ocultas el mapa y bajas el kart, la cámara, el suelo, la sombra, los rivales, las colisiones y buena parte de la lógica del juego siguen creyendo que Mario está donde estaba originalmente.

**Este hack no se limita a quitar el mapa: mueve la propia cámara y adapta todo lo que depende de ella.**

## La idea que hizo avanzar el proyecto

Al principio se intentó solucionar uno por uno cada problema provocado por mover el kart hacia abajo. El resultado fue una colección interminable de parches: cada cosa que se arreglaba descubría otra que seguía utilizando las coordenadas antiguas.

Hasta que surgió una idea mucho más útil: **aprovechar en 1P parte de la lógica que el juego ya utiliza para el Player 2**, cuyo kart se dibuja aproximadamente en la posición que necesitábamos.

Aquello no resolvía el hack por sí solo, pero permitió reutilizar una parte de la lógica existente en lugar de reconstruirla desde cero y ahorró muchísimo trabajo. A partir de ahí fue posible centrarse en hacer que la nueva cámara, la posición real del kart y el resto de la lógica del juego encajaran entre sí.

## Qué hace

* **Pantalla completa real en 1P.** La vista de carrera utiliza las 224 líneas de imagen completas y la cámara se acerca al kart de forma progresiva al comenzar la carrera.
* **Cámara coherente con la proyección.** El DSP-1 recibe un nuevo punto de enfoque adelantado en la dirección de la vista, de forma que el kart, el suelo, los rivales, los objetos, las sombras y las colisiones siguen utilizando la misma perspectiva y rotación.
* **HUD recolocado.** Se reorganizan los contadores, monedas y posiciones para aprovechar el nuevo espacio. El dígito grande de la posición final deja de pisar el dígito pequeño; este último se desplaza 8 píxeles hacia la izquierda.
* **Tablas y carteles recolocados.** La tabla de LAP TIME y las caras de clasificación se desplazan 25 píxeles hacia abajo. También se adaptan GAME OVER, ROUND, RANKED OUT y los menús RETRY / END.
* **Efectos y objetos adaptados a la nueva posición.** Se corrigen, entre otros, monedas perdidas, plátanos, humo de aplastamiento, topos y otros efectos que seguían utilizando la posición vertical original.
* **Colisiones ajustadas a la nueva proyección.** Se adaptan las comprobaciones contra rivales y obstáculos para que sigan funcionando cuando Mario ocupa una zona de pantalla mucho más baja. Desde la v1.2, el punto de la pista que hay bajo el kart coincide con el lugar donde el kart está dibujado, de modo que muros, bordes y vacíos reaccionan cuando el kart los toca, no antes.
* **El rescate de Lakitu funciona en pantalla completa.** Tras caer de la pista, Lakitu entra en pantalla, recoge el kart con la moneda y lo devuelve a la pista, como en el juego original. Desde la v1.3 no queda ninguna pieza de Lakitu asomando por la parte inferior de la pantalla tras su aparición en la salida o tras un rescate.
* **Modo 2P conservado.** El hack queda limitado a 1P mediante puertas específicas; en 2P se ejecuta la lógica original de la ROM. Se revisaron y neutralizaron los efectos secundarios que podían contaminar esa rama. Desde la v1.3 esto incluye la altura de la moneda de Lakitu y de las monedas perdidas en 2P, que podían dibujarse demasiado abajo tras jugar una carrera 1P en la misma sesión.
* **Numerosos efectos secundarios corregidos.** Durante el desarrollo aparecieron problemas con sprites que reaparecían por la parte superior o inferior, rivales que desaparecían demasiado pronto, cabezas de Lakitu que asomaban fuera de pantalla, efectos que seguían apareciendo en la posición original, parpadeos y otros artefactos. Se fueron localizando y corrigiendo a medida que aparecían.
* **Rendimiento ajustado.** Una primera solución provocaba ralentizaciones en escenas cargadas de la versión USA. Se perfiló el código y se redujo el coste de las rutinas más pesadas hasta recuperar el ritmo normal del juego. En la v1.2, la comprobación que decide si se aplica la lógica de pantalla completa se calcula una vez por fotograma en lugar de decenas de veces, lo que elimina las ralentizaciones de la escena más pesada probada (el rescate de Lakitu). La v1.3 reduce aún más la carga (comprobaciones más baratas en la proyección y en el descarte de objetos): en la salida de carrera más pesada probada, el pico de CPU baja del 95,7 % al 90,5 % (vanilla: 89 %), y no se midió ningún fotograma con lag en los primeros 1061 fotogramas de las salidas de la Copa Champiñón, Flor y Estrella (50cc).

## Una pequeña odisea de ingeniería inversa

Casi ningún problema se resolvió simplemente cambiando una coordenada.

El juego utiliza el **DSP-1**, Mode 7, HDMA, ventanas de color, OAM y varias capas de lógica de proyección y ordenación de objetos. Al modificar la cámara empezaron a aparecer problemas que a primera vista no parecían tener relación alguna con ella: rivales que atravesaban a Mario, tuberías que no colisionaban, objetos que desaparecían demasiado pronto, sprites que se partían o reaparecían arriba al superar el rango de una coordenada Y de 8 bits, efectos que seguían naciendo 88 píxeles por encima del kart o sombras que utilizaban las coordenadas de la posición antigua.

También fue necesario investigar el orden de dibujado de los karts, la construcción de la OAM y los criterios de profundidad utilizados por el juego. Algunas soluciones experimentales funcionaban visualmente, pero costaban demasiados ciclos de CPU y provocaban ralentizaciones en NTSC, así que hubo que descartarlas y buscar puntos de intervención mucho más baratos.

Cada corrección se volvió a probar contra las anteriores con estados reproducibles y comparaciones fotograma a fotograma para evitar que un arreglo rompiera otra parte del juego.

En otras palabras: **no se trataba de mover a Mario 88 píxeles hacia abajo; había que convencer a Super Mario Kart de que ahora la carrera ocurría en otra geometría de pantalla.**

## ¿Por qué no hay mapa ni retrovisor?

La idea inicial era conservarlos como pequeños recuadros sobre la vista completa.

El problema es que el mapa y el retrovisor no son simplemente imágenes que puedan colocarse en una esquina. Ambos utilizan Mode 7, HDMA y cálculos específicos para dividir la pantalla. Reintroducirlos significaba volver a partir el fotograma y complicar de nuevo la lógica que precisamente se había eliminado.

Al final se optó por una **pantalla de carrera limpia y completa**, que es el objetivo principal del hack.

## Cómo se ha hecho

El proyecto se ha desarrollado mediante ingeniería inversa de la ROM, instrumentación y pruebas reproducibles con estados de emulación.

Se han utilizado trazas de CPU/PPU, análisis de OAM y DMA, inspección de tablas y estructuras de memoria, herramientas específicas para desensamblado y perfilado y numerosas regresiones sobre estados de carrera, salida, colisiones, efectos, menús, resultados y situaciones especiales.

El proyecto se ha desarrollado **en colaboración con una IA**. La IA se ha encargado de buena parte de la implementación técnica —análisis del código, escritura de herramientas, parches y automatización de pruebas—, mientras que Psicopompo ha llevado la dirección del proyecto: investigar el funcionamiento del juego, plantear y descartar estrategias, interpretar los resultados, detectar problemas, decidir qué camino seguir y validar cada cambio.

## ROM y parche

Necesitas una ROM limpia de **Super Mario Kart (USA)**, sin cabecera:

|        | Valor                                      |
| ------ | ------------------------------------------ |
| Tamaño | 524.288 bytes                              |
| CRC32  | `CD80DB86`                                 |
| MD5    | `7f25ce5a283d902694c52fb1152fa61a`         |
| SHA-1  | `47e103d8398cf5b7cbb42b95df3a3c270691163b` |

Hay disponibles parches **IPS** y **BPS**. Se recomienda **BPS**, ya que comprueba la ROM de entrada antes de aplicar el parche.

* `Super Mario Kart - Fullscreen Edition (v1.3) (by Psicopompo).bps`
* `Super Mario Kart - Fullscreen Edition (v1.3) (by Psicopompo).ips`

La ROM resultante pasa a ocupar **1 MiB**:

|       | Valor                                      |
| ----- | ------------------------------------------ |
| CRC32 | `3CB1596A`                                 |
| MD5   | `ec6b1b54f95bba2e913ca527dd3772b8`         |
| SHA-1 | `bb0f215bbcd90f19e057bcc9fd6fd378c1b5cb46` |

Aplica el parche sobre una copia de tu ROM limpia.

## Historial de cambios

* **v1.3** – Las piezas sobrantes de Lakitu (los «tres pelos») ya no asoman por la parte inferior de la pantalla en Ghost Valley, en las caídas al agua ni en la salida. En 2P, la moneda de Lakitu y las monedas perdidas se dibujan a su altura correcta en lugar de 88 píxeles más abajo. Menos carga de CPU en 1P (pico en la salida más pesada probada: 95,7 % → 90,5 %). El comportamiento 1P no cambia en lo demás. Incluye las correcciones de la v1.2. El parche se aplica directamente sobre la ROM USA limpia.
* **v1.2** – La proyección del suelo se realinea con la posición del kart en pantalla, de forma que la pista bajo el kart coincide con el lugar donde el kart está dibujado: las colisiones con muros, bordes y vacíos ocurren ahora en el sitio correcto (antes saltaban demasiado pronto). Se corrige el rescate de Lakitu tras caer de la pista (entra en pantalla, recoge el kart y lo sube con la moneda). Ralentizaciones reducidas: la comprobación que decide si se aplica la lógica de pantalla completa se calcula una vez por fotograma y, en la escena más pesada probada (el rescate de Lakitu), los fotogramas con lag pasan del 18 % a prácticamente cero. Incluye las correcciones de la v1.1. El parche se aplica directamente sobre la ROM USA limpia.
* **v1.1** – Corrige unos píxeles blancos sueltos que aparecían en consola real en la banda de transición de la imagen (en la mayoría de emuladores no se ven). La tabla de LAP TIME y las caras de clasificación bajan 5 píxeles más. El parche se aplica directamente sobre la ROM USA limpia.
* **v1.0** – Primera versión.

## Notas y limitaciones

* **Solo versión USA** (224 líneas / 60 Hz). La versión PAL no está soportada.
* Probado en **bsnes** y **RetroArch**.
* **Hardware real:** la corrección de píxeles blancos de la v1.1 se confirmó en hardware real por un probador. La v1.2 y la v1.3 aún no se han probado en hardware real, y los flashcarts tampoco.
* Las copas de **50cc y 100cc** se completaron con la v1.1; la v1.3 se ha comprobado con regresiones por estados, comparación fotograma a fotograma, mediciones de rendimiento y sesiones de juego. Otros modos tienen un nivel de validación menor.
* Los objetos y efectos de pista siguen las reglas del juego original; al disponer de una cámara mucho más cercana, algunos límites de aparición y descarte pueden resultar más visibles.
* El modo 2P conserva la lógica original del juego y no utiliza la cámara de pantalla completa de 1P.

## Pantalla de título

El título incluye una pequeña línea blanca:

*Fullscreen Edition · Psicopompo*

situada bajo el copyright de Nintendo.

Además, el texto de copyright original, que estaba ligeramente desplazado, ha sido recentrado.

## Créditos y aviso

**Psicopompo** — dirección del proyecto, investigación, análisis, diseño de las soluciones, pruebas y validación.

**IA** — análisis de código, implementación de los parches, herramientas auxiliares y automatización de pruebas, bajo dirección de Psicopompo.

Super Mario Kart © Nintendo. Proyecto de aficionado no oficial, sin relación con Nintendo ni respaldado por ella.

Debes aportar tu propia ROM obtenida legalmente. Este parche no distribuye datos de la ROM original.

Si encuentras algún fallo, lo ideal es enviar un **save state** que permita reproducirlo.
