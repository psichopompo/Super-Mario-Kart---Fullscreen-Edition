# Super Mario Kart – Fullscreen Edition (USA)

A hack that turns the **1-player race view in Super Mario Kart** into a true fullscreen display.

The track uses the full **256×224 pixels** available, the camera is moved closer to the kart, and everything that depended on the original layout — HUD, text, effects, objects, collisions, and other screen elements — is adapted to the new perspective.

Made by **Psicopompo**.

## Why it exists

In 1-player mode, Super Mario Kart reserves part of the screen for the map and rear-view mirror, inherited from the split-screen design of 2-player mode.

Removing that area sounds simple, but it is only the beginning. If you simply hide the map and move the kart down, the camera, ground, shadow, rivals, collisions, and much of the game's logic still assume that Mario is where he originally was.

**This hack does not simply remove the map: it moves the camera itself and adapts everything that depends on it.**

## The idea that made the project move forward

At first, the approach was to fix each problem caused by moving the kart downward one by one. The result was an endless collection of patches: every problem that was fixed revealed another one that was still using the old coordinates.

Then came a much more useful idea: **reuse part of the logic the game already uses for Player 2**, whose kart is drawn roughly in the position we needed.

That did not solve the hack by itself, but it allowed part of the existing logic to be reused instead of rebuilding it from scratch, saving a huge amount of work. From that point on, it became possible to focus on making the new camera, the kart's actual position, and the rest of the game's logic work together.

## What it does

* **True fullscreen in 1P.** The race view uses all 224 visible lines, and the camera moves closer to the kart progressively as the race begins.
* **Camera consistent with the projection.** The DSP-1 receives a new focus point moved forward in the direction of the view, so the kart, ground, rivals, objects, shadows, and collisions continue to use the same perspective and rotation.
* **HUD repositioned.** Counters, coins, and position indicators are rearranged to take advantage of the new space. The large position digit no longer overlaps the small digit; the small one is moved 8 pixels to the left.
* **Tables and banners repositioned.** The LAP TIME table and standings faces are moved 25 pixels downward. GAME OVER, ROUND, RANKED OUT, and the RETRY / END menus are also adapted.
* **Effects and objects adapted to the new position.** Among other things, lost coins, bananas, crush smoke, Monty Moles, and other effects that were still using the original vertical position are corrected.
* **Collisions adjusted to the new projection.** Collision checks against rivals and obstacles are adapted so they continue to work when Mario occupies a much lower area of the screen. Since v1.2 the point of the track under the kart matches where the kart is actually drawn, so walls, track edges and pits react when the kart touches them, not before.
* **Lakitu's rescue works in fullscreen.** After falling off the track, Lakitu comes into view, picks up the kart with the coin and lifts it back, as in the original game. Since v1.3 no piece of Lakitu is left peeking out at the bottom of the screen after his appearance at the start or after a rescue.
* **2P mode preserved.** The hack is restricted to 1P through dedicated gates; in 2P, the original ROM logic runs. Side effects that could leak into the 2P branch were also tracked down and neutralized; since v1.3 this includes the height of Lakitu's coin and of lost coins in 2P, which could be drawn too low after playing a 1P race in the same session.
* **Numerous side effects fixed.** During development, sprites could reappear at the top or bottom of the screen, rivals could disappear too early, Lakitu's head could appear outside the visible area, effects could remain tied to their original position, and various flickering and graphical artifacts could occur. They were located and corrected as they appeared.
* **Performance tuned.** An early solution caused slowdown in heavily loaded scenes in the USA version. The code was profiled and the most expensive routines were optimized until normal game speed was restored. In v1.2 the check that decides whether the fullscreen logic applies is computed once per frame instead of dozens of times, which removes the slowdowns in the heaviest scene tested (Lakitu's rescue). v1.3 trims the load further (cheaper checks in the projection and object-culling code): in the heaviest race start tested the peak CPU load drops from 95.7 % to 90.5 % (vanilla: 89 %), and no lagged frames were measured in the first 1061 frames of the Mushroom, Flower and Star Cup starts (50cc).

## A small reverse-engineering odyssey

Almost no problem could be solved simply by changing a coordinate.

The game uses the **DSP-1**, Mode 7, HDMA, color windows, OAM, and several layers of projection and object-ordering logic. Changing the camera caused problems that initially seemed unrelated to it: rivals passing through Mario, pipes failing to collide, objects disappearing too early, sprites splitting apart or wrapping around when they exceeded the range of an 8-bit Y coordinate, effects still appearing 88 pixels above the kart, and shadows still using the old position.

The drawing order of the karts, OAM construction, and the game's depth-sorting rules also had to be investigated. Some experimental solutions looked correct but cost too many CPU cycles and caused slowdowns in NTSC, so they had to be discarded in favor of much cheaper intervention points.

Every fix was retested against the previous ones using reproducible states and frame-by-frame comparisons to make sure one solution did not break something else.

In other words: **this was not a matter of moving Mario 88 pixels downward; Super Mario Kart had to be convinced that the race was now taking place on a different screen geometry.**

## Why is there no map or rear-view mirror?

The original idea was to keep them as small windows over the full race view.

The problem is that the map and rear-view mirror are not simply images that can be placed in a corner. Both use Mode 7, HDMA, and specific calculations designed around the split-screen layout. Bringing them back would mean splitting the frame again and complicating the very logic that had been removed.

In the end, the decision was made to keep a **clean, full-screen race view**, which is the main goal of the hack.

## How it was made

The project was developed through ROM reverse engineering, instrumentation, and reproducible testing with emulator states.

CPU/PPU traces, OAM and DMA analysis, memory tables and structures, dedicated disassembly and profiling tools, and extensive regression testing were used across race starts, collisions, effects, menus, results screens, and special situations.

The project was developed **in collaboration with an AI**. The AI handled a large part of the technical implementation — code analysis, tool writing, patch implementation, and test automation — while Psicopompo directed the project: investigating how the game worked, proposing and discarding strategies, interpreting results, identifying problems, deciding what path to take, and validating every change.

## ROM and patch

You need a clean **Super Mario Kart (USA)** ROM, without a header:

|       | Value                                      |
| ----- | ------------------------------------------ |
| Size  | 524,288 bytes                              |
| CRC32 | `CD80DB86`                                 |
| MD5   | `7f25ce5a283d902694c52fb1152fa61a`         |
| SHA-1 | `47e103d8398cf5b7cbb42b95df3a3c270691163b` |

Both **IPS** and **BPS** patches are available. **BPS is recommended**, since it checks the input ROM before applying the patch.

* `Super Mario Kart - Fullscreen Edition (v1.3) (by Psicopompo).bps`
* `Super Mario Kart - Fullscreen Edition (v1.3) (by Psicopompo).ips`

The resulting ROM is expanded to **1 MiB**:

|       | Value                                      |
| ----- | ------------------------------------------ |
| CRC32 | `3CB1596A`                                 |
| MD5   | `ec6b1b54f95bba2e913ca527dd3772b8`         |
| SHA-1 | `bb0f215bbcd90f19e057bcc9fd6fd378c1b5cb46` |

Apply the patch to a copy of your clean ROM.

## Changelog

* **v1.3** – Lakitu's leftover pieces (the "three hairs") no longer peek out at the bottom of the screen in Ghost Valley, the water falls and at the start. In 2P, Lakitu's coin and lost coins are drawn at the right height instead of 88 pixels too low. Lower CPU load in 1P (peak load in the heaviest start tested: 95.7 % → 90.5 %). 1P behaviour is otherwise unchanged. Includes the v1.2 fixes. The patch applies directly to the clean USA ROM.
* **v1.2** – The ground projection is realigned with the kart's on-screen position, so the track under the kart matches where the kart is drawn: collisions with walls, edges and pits now happen at the right place (they used to trigger too early). Lakitu's rescue after falling off the track is fixed (he comes into view, picks up the kart and lifts it with the coin). Slowdowns reduced: the check that decides whether the fullscreen logic applies is computed once per frame, and in the heaviest scene tested (Lakitu's rescue) lagged frames drop from 18 % to practically zero. Includes the v1.1 fixes. The patch applies directly to the clean USA ROM.
* **v1.1** – Fixes a few stray white pixels that appeared on real hardware in the transition band of the picture (not visible in most emulators). The LAP TIME table and standings faces are moved 5 pixels further down. The patch applies directly to the clean USA ROM.
* **v1.0** – First release.

## Notes and limitations

* **USA version only** (224 lines / 60 Hz). The PAL version is not supported.
* Tested with **bsnes** and **RetroArch**.
* **Real hardware:** the v1.1 white-pixel fix was confirmed on real hardware by a tester. v1.2 and v1.3 have not been tested on real hardware yet, and flashcarts have not been tested.
* The **50cc and 100cc Cups** were completed with v1.1; v1.3 has been checked with state-by-state regression, frame-by-frame comparison, performance measurements and play sessions. Other modes have received less testing.
* Track objects and effects still follow the original game's rules; with the much closer camera, some spawn and despawn limits may be more noticeable.
* 2P mode retains the original game logic and does not use the 1P fullscreen camera.

## Title screen

The title screen includes a small white line:

*Fullscreen Edition · Psicopompo*

placed below Nintendo's copyright.

The original copyright text, which was slightly misaligned, has also been recentered.

## Credits and disclaimer

**Psicopompo** — project direction, research, analysis, solution design, testing, and validation.

**AI** — code analysis, patch implementation, auxiliary tools, and test automation, under Psicopompo's direction.

Super Mario Kart © Nintendo. Unofficial fan project, not affiliated with or endorsed by Nintendo.

You must provide your own legally obtained ROM. This patch does not distribute data from the original ROM.

If you find a bug, the best way to report it is to provide a **save state** that reproduces it.
