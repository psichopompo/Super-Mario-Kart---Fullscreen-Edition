# Super Mario Kart – Fullscreen Edition v2.0 · Changelog

Base: **clean, unheadered Super Mario Kart USA** (CRC32 `CD80DB86`).
Cumulative patch over the original, never over earlier versions.

| | |
|---|---|
| Final v2.0 ROM | 1,048,576 bytes |
| CRC32 | `E9B8C210` |
| MD5 | `0f4d2c70b6057c8af55f584244d78911` |
| SHA-256 | `008a5cedb569d07487b93dbfdb0c09c98f2b30cfecfe41916fee663c5fc9992b` |
| Internal checksum | sum `0A97` at `FFDE`, complement `F568` at `FFDC` |

Everything listed here was verified on the reference emulator (bsnes) using frame
batteries, real race states and pixel-by-pixel comparisons.

> **Note on this build.** The previous v2.0 ROM (CRC32 `4477080A`) had the internal
> checksum fields swapped: the sum in `FFDC` and the complement in `FFDE`, the reverse
> of the original ROM. This build puts them in the correct order. The difference
> between the two ROMs is **exactly those 4 bytes** (`FFDC`–`FFDF`); there is no other
> code or data change. The earlier `A60473E0` and `0BDD9C54` builds remain as
> historical references.

## New: wide-horizon camera

- **New single-player camera, enabled by default** on all 20 tracks: a more open,
  higher view with its own horizon, also in the intro, the start zoom and the finish
  turn.
- **Select during a race** toggles between the new and the classic camera on the fly
  (one press = one change; it does nothing in menus; checked in pause, TT and restarts).
- **Optional classic camera**, identical to the original game, for those who prefer it.

## Backgrounds adapted on all 20 tracks

- Extended skies with no black bands or colour jumps; upper fills use the tone of the
  adjacent gradient band.
- **Mario Circuit 1 and Donut Plains 1** were adapted and approved first; the rest of
  the families (Ghost, Koopa, Choco, Bowser, Rainbow, etc.) followed.
- **Koopa Beach 1 and 2**: clouds at all three heights from the starting grid, filled
  with the top tone of the gradient, with no dark band at the seam.
- **Ghost Valley**: pillars clipped, no debris off-screen.

## Glitches and bugs fixed

- **Duplicated player face on winning the race**: no face remnant is left at the top of
  the screen during the finish camera (f15–17 clean).
- **Posts at the top of the ghost track** (Ghost Valley): the pillars that showed up top
  with the new view are now hidden; only their sprite is touched, with no effect on
  actors, collision or shadows.
- **Mountain flicker while loading**: fixed.
- **Intermittent black/blue lines in Ghost Valley**: the colour of the rows before the
  gradient is fixed.
- **Time Trial finish with the new camera**: results and the finish transition behave
  the same with both cameras.
- **Oil slick using the native threshold**: contact is detected with the original
  condition; no false slides.
- **ROUND banner re-centred** in the new 1P view, as in earlier versions of the hack.

## Attract mode and performance

- **Attract mode resynchronised**: cold-boot demos show rivals correctly on screen;
  compared against the original ROM, identical except for the hack's signature.
- **CPU cycle reduction**: the scale lookup, the sprite culling and the sprite/HUD
  placement helpers in bank `$88` were rewritten without redundant stack use, and some
  nested `PHP/PLP` calls were replaced by direct 4-cycle reads. Two-player mode and the
  demos stop accumulating lag; single-player gains headroom. The calls that decide the
  banner and HUD repositioning keep the complete original logic so their position is
  unchanged. The rendered output is identical to before (0 differences in the
  regression suite).

## Checksum and flashcarts

- **Internal checksum corrected and verified**: the sum of the whole ROM (`0A97`)
  matches the header field, and its complement (`F568`) sits in the adjacent field, in
  the same order the original ROM uses. No checksum error should appear on flashcarts or
  in patchers.

## Deliberately unchanged

- Original AI logic and physics untouched (agreed criterion: do not force replays).
- Two-player mode identical to the original game.
- Mario Circuit 1 and Donut Plains 1 keep their round-by-round approval.

## Carried over from v1.5

- The Time Trial results fix approved at the time.
- The R5 rival size distribution (geometric progression, factor ≈ 1.3703).

## Validation summary for this build

- Cold attract mode, 2950 frames vs the original USA ROM: identical except for the
  hack's signature.
- 27 real race states × 120 frames: 0 rendering differences against the previous base
  with the portrait fix.
- Finish-camera OAM (TT and podium) identical to the build with the approved face fix.
- Performance measured on Bowser Castle 1/3: the same clock ticks as the original ROM
  (the hard-turn stutter is native game behaviour, not the patch).
- IPS and BPS patches generated and verified with Floating IPS: applied to the clean
  USA ROM they reproduce the final ROM byte for byte.

## Limits

No real hardware or flashcart testing is claimed, and the SNES9x core from the forum
thread was not tested.
