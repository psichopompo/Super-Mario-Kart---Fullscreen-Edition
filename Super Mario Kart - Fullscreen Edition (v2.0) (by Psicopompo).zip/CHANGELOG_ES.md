# Super Mario Kart – Fullscreen Edition v2.0 · Notas de cambio

Base: **Super Mario Kart USA limpia, sin cabecera** (CRC32 `CD80DB86`).
Parche acumulativo sobre la original, nunca sobre versiones anteriores.

| | |
|---|---|
| ROM final v2.0 | 1.048.576 bytes |
| CRC32 | `E9B8C210` |
| MD5 | `0f4d2c70b6057c8af55f584244d78911` |
| SHA-256 | `008a5cedb569d07487b93dbfdb0c09c98f2b30cfecfe41916fee663c5fc9992b` |
| Checksum interno | suma `0A97` en `FFDE`, complemento `F568` en `FFDC` |

Todo lo listado está verificado en emulación de referencia (bsnes) con baterías de
fotogramas, estados de carrera reales y comparaciones píxel a píxel.

> **Nota sobre esta build.** La ROM v2.0 anterior (CRC32 `4477080A`) tenía los campos
> del checksum interno intercambiados: la suma en `FFDC` y el complemento en `FFDE`, al
> revés que la ROM original. En esta build se han colocado en el orden correcto. La
> diferencia entre ambas ROM es **exactamente esos 4 bytes** (`FFDC`–`FFDF`); no hay
> ningún otro cambio de código ni de datos. Las builds anteriores `A60473E0` y
> `0BDD9C54` quedan como referencia histórica.

## Lo nuevo: cámara de horizonte amplio

- **Cámara nueva de 1 jugador, activada por defecto** en los 20 circuitos: vista más
  abierta y alta con horizonte propio, también en intro, zoom de salida y giro de meta.
- **Select durante la carrera** alterna al vuelo entre cámara nueva y clásica
  (una pulsación = un cambio; en menús no hace nada; comprobado en pausa, TT y
  reinicios).
- **Cámara clásica opcional** idéntica al juego original para quien la prefiera.

## Decorados adaptados en los 20 circuitos

- Cielos extendidos sin bandas negras ni saltos de color; rellenos superiores con el
  tono de la franja adyacente del degradado.
- **Mario Circuit 1 y Donut Plains 1** adaptados y aprobados primero; después el resto
  de familias (Ghost, Koopa, Choco, Bowser, Rainbow, etc.).
- **Koopa Beach 1 y 2**: nubes en las tres alturas desde la parrilla y relleno con el
  tono superior del degradado, sin banda oscura en la unión.
- **Ghost Valley**: pilares recortados y sin basura fuera de pantalla.

## Glitches y bugs corregidos

- **Cara duplicada del jugador al ganar la carrera**: ya no queda un resto de cara en lo
  alto de la pantalla durante la cámara de meta (f15–17 limpios).
- **Postes en la parte superior del circuito de los fantasmas** (Ghost Valley): los
  pilares que asomaban arriba con la vista nueva ahora se ocultan; solo se toca su
  sprite, sin afectar a actores, colisiones ni sombras.
- **Parpadeo de montañas al cargar**: corregido.
- **Líneas negras/azules intermitentes en Ghost Valley**: corregido el color de las
  filas anteriores al degradado.
- **Meta de Time Trial con cámara nueva**: los resultados y la transición de meta
  funcionan igual con ambas cámaras.
- **Mancha de aceite con umbral nativo**: el contacto se detecta con la condición
  original; sin resbalones falsos.
- **Letrero ROUND centrado** en la vista nueva de 1P, como en las versiones anteriores
  del hack.

## Attract mode y rendimiento

- **Attract mode resincronizado**: las demos en frío muestran los rivales correctamente
  en pantalla; comparado contra la ROM original, idéntico salvo la firma del hack.
- **Reducción de ciclos de CPU**: se reescribieron sin pila redundante la búsqueda de
  escala, el *culling* de sprites y los *helpers* de colocación de sprites/HUD del banco
  `$88`, y parte de las llamadas anidadas con `PHP/PLP` se sustituyeron por lecturas
  directas de 4 ciclos. El modo 2P y las demos dejan de acumular *lag*; en 1P la CPU
  gana colchón. Las llamadas que deciden la recolocación del letrero y el HUD conservan
  la lógica original completa para no alterar su posición. El resultado renderizado es
  idéntico al de antes (0 diferencias en la batería de regresión).

## Checksum y flashcards

- **Checksum interno corregido y verificado**: la suma de toda la ROM (`0A97`) coincide
  con el campo de cabecera y su complemento (`F568`) está en el campo contiguo, en el
  mismo orden que cumple la ROM original. No debe dar error de checksum en flashcards ni
  parcheadores.

## Sin cambios a propósito

- Lógica de IA y físicas originales intactas (criterio acordado: no forzar repeticiones).
- Modo 2 jugadores idéntico al juego original.
- Mario Circuit 1 y Donut Plains 1 conservan su aprobación ronda a ronda.

## Heredado de la v1.5

- Corrección de resultados de Time Trial aprobada en su día.
- Reparto de tamaños R5 de los rivales (progresión geométrica, factor ≈ 1,3703).

## Validación resumida de esta build

- Attract en frío, 2950 fotogramas vs USA original: idéntico salvo la firma del hack.
- 27 estados de carrera reales × 120 fotogramas: 0 diferencias de renderizado frente a
  la base anterior con el fix de retratos.
- OAM de las cámaras de meta (TT y podio) idéntico a la build con el fix de cara
  aprobado.
- Rendimiento medido en Bowser Castle 1/3: mismos tics de reloj que la ROM original
  (el tartamudeo de giros duros es comportamiento nativo del juego, no del parche).
- Parches IPS y BPS generados y verificados con Floating IPS: aplicados sobre la USA
  limpia reproducen la ROM final byte a byte.

## Límites

No se certifica hardware real ni flashcard, y no se ha probado sobre el core SNES9x del
hilo del foro.
