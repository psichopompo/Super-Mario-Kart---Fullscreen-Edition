# Super Mario Kart – Fullscreen Edition v2.0 (USA)

Un hack que convierte la vista de carrera de **1 jugador de Super Mario Kart** en una
pantalla completa de verdad, y que en esta versión añade una **cámara de horizonte
amplio** con decorados adaptados en los 20 circuitos.

La pista ocupa las **256×224 píxeles** disponibles, la cámara se acerca al kart y todo lo
que dependía de la distribución original —HUD, textos, efectos, objetos, colisiones y
demás elementos de pantalla— se adapta a la nueva perspectiva.

Hecho por **Psicopompo**.

---

## Archivos de este paquete

| Archivo | Descripción |
|---|---|
| `Super Mario Kart - Fullscreen Edition (v2.0) (by Psicopompo).bps` | Parche BPS (recomendado: verifica la ROM de origen) |
| `Super Mario Kart - Fullscreen Edition (v2.0) (by Psicopompo).ips` | Parche IPS (mismo resultado) |
| `LÉEME.md` | Este documento (español) |
| `README.md` | English version |
| `CHANGELOG_ES.md` | Notas de cambio detalladas (español) |
| `CHANGELOG_EN.md` | Detailed changelog (English) |

**Este paquete no contiene ninguna ROM.** Necesitas tu propia copia de
Super Mario Kart (USA).

---

## Cómo aplicarlo

1. Consigue la ROM **Super Mario Kart (USA), sin cabecera, 524.288 bytes,
   CRC32 `CD80DB86`**.
2. Aplica el BPS con [flips](https://github.com/Alcaro/Flips) o el IPS con Lunar IPS
   (o cualquier parcheador equivalente).
3. El parche es **acumulativo sobre la ROM original**: no se aplica encima de la v1.4
   ni de la v1.5. Siempre sobre la USA limpia.
4. Carga la ROM resultante en tu emulador o flashcard.

### Verificación

| | Valor |
|---|---|
| ROM de origen | 524.288 bytes · CRC32 `CD80DB86` · MD5 `7f25ce5a283d902694c52fb1152fa61a` |
| ROM resultante | 1.048.576 bytes · CRC32 `E9B8C210` |
| MD5 resultante | `0f4d2c70b6057c8af55f584244d78911` |
| SHA-256 resultante | `008a5cedb569d07487b93dbfdb0c09c98f2b30cfecfe41916fee663c5fc9992b` |

Ambos parches se han verificado aplicándolos de vuelta sobre la USA limpia con
Floating IPS: el resultado coincide byte a byte con la ROM de referencia.

El **checksum interno está corregido**: la suma de la ROM (`0A97`) y su complemento
(`F568`) ocupan los campos `FFDE` y `FFDC` en el mismo orden que la ROM original, así
que no debería dar aviso de checksum en flashcards ni parcheadores.

---

## Controles

- **Select durante la carrera** alterna al vuelo entre la cámara nueva y la clásica.
  Una pulsación = un cambio.
- Select **no hace nada en los menús**: no hay ningún otro comportamiento añadido.
- El modo **2 jugadores no cambia**: sigue siendo pantalla partida, idéntica al juego
  original.

---

## Novedades de la v2.0

### Cámara de horizonte amplio

- **Cámara nueva de 1 jugador, activada por defecto** en los 20 circuitos: vista más
  abierta y alta, con horizonte propio. También en la intro, el zoom de salida y el
  giro de meta.
- **Cámara clásica opcional**, idéntica al juego original, conmutable con Select.

### Decorados adaptados en los 20 circuitos

- Cielos extendidos sin bandas negras ni saltos de color; los rellenos superiores usan
  el tono de la franja adyacente del degradado.
- **Koopa Beach 1 y 2**: nubes en las tres alturas desde la parrilla y relleno con el
  tono superior del degradado, sin banda oscura en la unión.
- **Ghost Valley**: pilares recortados, sin basura asomando por arriba.
- **Mario Circuit 1 y Donut Plains 1** se adaptaron y aprobaron primero; después el
  resto de familias (Ghost, Koopa, Choco, Bowser, Rainbow…).

### Glitches corregidos

- **Cara duplicada del jugador al ganar**: ya no queda un resto de cara en lo alto de la
  pantalla durante la cámara de meta.
- **Parpadeo de montañas al cargar**: corregido.
- **Líneas negras y azules intermitentes en Ghost Valley**: corregido el color de las
  filas anteriores al degradado.
- **Mancha de aceite con el umbral nativo**: el contacto se detecta con la condición
  original del juego; sin resbalones falsos.
- **Letrero ROUND centrado** en la vista nueva de 1P, como en las versiones anteriores
  del hack.
- **Meta de Time Trial con cámara nueva**: resultados y transición de meta funcionan
  igual con ambas cámaras.

### Attract mode y rendimiento

- **Attract mode resincronizado**: las demos en frío muestran a los rivales
  correctamente en pantalla.
- **Reducción de ciclos de CPU**: se reescribieron sin pila redundante la búsqueda de
  escala, el *culling* de sprites y los *helpers* de colocación de sprites y HUD. El
  modo 2P y las demos dejan de acumular *lag*; en 1P la CPU gana colchón. El resultado
  renderizado es idéntico al anterior (0 diferencias en la batería de regresión).

---

## Lo que se conserva de la v1.5

- **Corrección de Time Trial**: todas las vueltas, sus resaltados, TOTAL y el mapa con
  BEST 5 / BEST LAP en los resultados.
- **Progresión geométrica de tamaños de los rivales** (factor ≈ 1,3703 en las franjas
  T1–T10), con los once dibujos originales intactos.
- **Parrilla corregida desde el inicio** del acercamiento, conservando intro, zoom y
  órbita.
- **Lakitu y sombras** corregidos en fullscreen y en las dos vistas de 2P.

---

## Rendimiento y el tartamudeo de Bowser Castle

Se midió antes de empaquetar, con el mismo emulador de referencia (bsnes) y guiones de
giros duros a alta velocidad:

- **Bowser Castle 3** (estado de carrera real): v1.5 y v2.0 producen el mismo número de
  tics de reloj (2993 de 3000 fotogramas) y el mismo tiempo final. La v2.0 no añade
  ralentización sobre lo que ya se jugaba.
- **Bowser Castle 1** (el circuito del hilo del foro), Time Trial arrancado en frío con
  la ROM original USA, la v1.5 y la v2.0: las tres dan **exactamente** los mismos tics
  (11640 de 12000) y los mismos tiempos parciales y final, con la misma trayectoria.

Es decir: el tartamudeo en los giros duros es **comportamiento nativo del juego**,
idéntico con y sin parche. Por eso esta versión no modifica la planificación de la IA
ni las físicas.

---

## Sin cambios a propósito

- **Lógica de IA y físicas originales intactas.**
- **Modo 2 jugadores idéntico** al juego original.
- **Mario Circuit 1 y Donut Plains 1** conservan su aprobación ronda a ronda.

---

## Límites de las pruebas

Las validaciones son de emulación (bsnes/RetroArch) con baterías de fotogramas,
estados de carrera reales y comparaciones píxel a píxel. **No se certifica hardware
real ni flashcard**, y no se ha probado sobre el core SNES9x del hilo del foro.

Si el BPS avisa de origen incorrecto, estás aplicando sobre una ROM que no es la USA
limpia sin cabecera.
