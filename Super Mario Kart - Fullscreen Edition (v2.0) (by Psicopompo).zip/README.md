# Super Mario Kart – Fullscreen Edition v2.0 (USA)

A hack that turns **single-player racing in Super Mario Kart** into a genuine
full-screen view, and in this release adds a **wide-horizon camera** with backgrounds
adapted across all 20 tracks.

The track fills the available **256×224 pixels**, the camera moves closer to the kart,
and everything that depended on the original layout —HUD, banners, effects, items,
collision and the rest of the on-screen elements— is adapted to the new perspective.

By **Psicopompo**.

---

## Contents of this package

| File | Description |
|---|---|
| `Super Mario Kart - Fullscreen Edition (v2.0) (by Psicopompo).bps` | BPS patch (recommended: it verifies the source ROM) |
| `Super Mario Kart - Fullscreen Edition (v2.0) (by Psicopompo).ips` | IPS patch (same result) |
| `LÉEME.md` | Spanish version of this document |
| `README.md` | This document (English) |
| `CHANGELOG_ES.md` | Detailed changelog (Spanish) |
| `CHANGELOG_EN.md` | Detailed changelog (English) |

**This package contains no ROM.** You need your own copy of Super Mario Kart (USA).

---

## How to apply

1. Get the **Super Mario Kart (USA) ROM, unheadered, 524,288 bytes, CRC32 `CD80DB86`**.
2. Apply the BPS with [flips](https://github.com/Alcaro/Flips), or the IPS with Lunar
   IPS (or any equivalent patcher).
3. The patch is **cumulative over the original ROM**: do not apply it on top of v1.4 or
   v1.5. Always patch the clean USA ROM.
4. Load the resulting ROM in your emulator or flashcart.

### Verification

| | Value |
|---|---|
| Source ROM | 524,288 bytes · CRC32 `CD80DB86` · MD5 `7f25ce5a283d902694c52fb1152fa61a` |
| Output ROM | 1,048,576 bytes · CRC32 `E9B8C210` |
| Output MD5 | `0f4d2c70b6057c8af55f584244d78911` |
| Output SHA-256 | `008a5cedb569d07487b93dbfdb0c09c98f2b30cfecfe41916fee663c5fc9992b` |

Both patches were verified by applying them back to the clean USA ROM with Floating
IPS: the output matches the reference ROM byte for byte.

The **internal checksum is corrected**: the ROM sum (`0A97`) and its complement
(`F568`) sit in the `FFDE` and `FFDC` fields in the same order as the original ROM, so
no checksum warning should appear on flashcarts or in patchers.

---

## Controls

- **Select during a race** toggles between the new camera and the classic one on the
  fly. One press = one change.
- Select **does nothing in the menus**: no other behaviour was added.
- **Two-player mode is unchanged**: it remains split-screen, identical to the original
  game.

---

## New in v2.0

### Wide-horizon camera

- **New single-player camera, enabled by default** on all 20 tracks: a more open,
  higher view with its own horizon. Also in the intro, the start zoom and the finish
  turn.
- **Optional classic camera**, identical to the original game, switchable with Select.

### Backgrounds adapted on all 20 tracks

- Extended skies with no black bands or colour jumps; upper fills use the tone of the
  adjacent gradient band.
- **Koopa Beach 1 and 2**: clouds at all three heights straight from the starting grid,
  filled with the top tone of the gradient, with no dark band at the seam.
- **Ghost Valley**: pillars clipped, no debris poking in from the top.
- **Mario Circuit 1 and Donut Plains 1** were adapted and approved first; the rest of
  the families (Ghost, Koopa, Choco, Bowser, Rainbow…) followed.

### Glitches fixed

- **Duplicated player face on winning**: no face remnant is left at the top of the
  screen during the finish camera.
- **Mountain flicker while loading**: fixed.
- **Intermittent black and blue lines in Ghost Valley**: the colour of the rows before
  the gradient is fixed.
- **Oil slick using the native threshold**: contact is detected with the game's
  original condition; no false slides.
- **ROUND banner re-centred** in the new 1P view, as in earlier versions of the hack.
- **Time Trial finish with the new camera**: results and the finish transition behave
  the same with both cameras.

### Attract mode and performance

- **Attract mode resynchronised**: cold-boot demos now show rivals correctly on screen.
- **CPU cycle reduction**: the scale lookup, the sprite culling and the sprite/HUD
  placement helpers were rewritten without redundant stack use. Two-player mode and the
  demos stop accumulating lag; single-player gains headroom. The rendered output is
  identical to before (0 differences in the regression suite).

---

## Carried over from v1.5

- **Time Trial fix**: every lap, its highlight, TOTAL and the map with BEST 5 /
  BEST LAP in the results.
- **Geometric rival size progression** (factor ≈ 1.3703 across bands T1–T10), with all
  eleven original drawings intact.
- **Starting-grid correction from the beginning** of the camera approach, keeping the
  intro, zoom and orbit.
- **Lakitu and shadows** corrected in fullscreen and in both 2P views.

---

## Performance and the Bowser Castle stutter

Measured before packaging, on the same reference emulator (bsnes), with scripted hard
turns at high speed:

- **Bowser Castle 3** (real race state): v1.5 and v2.0 produce the same number of clock
  ticks (2993 of 3000 frames) and the same final time. v2.0 adds no slowdown over what
  you were already playing.
- **Bowser Castle 1** (the track from the forum thread), Time Trial cold-booted with
  the original USA ROM, v1.5 and v2.0: all three give **exactly** the same ticks
  (11640 of 12000) and the same split and final times, along the same trajectory.

In other words, the stutter through hard turns is **native game behaviour**, identical
with and without the patch. That is why this release does not touch AI scheduling or
physics.

---

## Deliberately unchanged

- **Original AI logic and physics, untouched.**
- **Two-player mode identical** to the original game.
- **Mario Circuit 1 and Donut Plains 1** keep their round-by-round approval.

---

## Testing limits

Validation is emulation-based (bsnes/RetroArch) using frame batteries, real race states
and pixel-by-pixel comparisons. **No real hardware or flashcart testing is claimed**,
and the SNES9x core from the forum thread was not tested.

If the BPS reports a wrong source, you are patching something other than the clean,
unheadered USA ROM.
