# Super Mario Kart – Fullscreen Edition v3.0
**by Psicopompo**

## ABOUT

A full-screen version of Super Mario Kart that brings the single-player races to the entire 256×224 screen.

Version 3.0 introduces several major improvements:

- **SA-1 upgrade:** The hack has been migrated from the DSP-1 to the SA-1 chip.
- **Floating minimap:** A new minimap displays the track layout during races.
- **Second camera:** An alternative camera perspective can be selected during gameplay.
- **Improved backgrounds:** Refined sky gradients and graphical improvements.
- **Performance improvements:** Further optimizations and bug fixes.
- **Flashcart compatibility:** Support for FXPAK Pro and SD2SNES.

Two-player mode retains the original split-screen layout.

## PATCHING

Two patches are included:

- `SMK_Fullscreen_USA.bps` (recommended)
- `SMK_Fullscreen_USA.ips`

Apply the patch to a clean, unheadered USA ROM:

**Super Mario Kart (USA).sfc**
- Size: 524,288 bytes
- CRC32: `CD80DB86`

The resulting ROM is 4 MB (4,194,304 bytes), with the corrected SNES header checksum:

- Checksum: `AE16`
- Checksum complement: `51E9`

**BPS:** The recommended option. It verifies the source ROM before applying the patch.

**IPS:** Does not verify the source ROM. It has been verified against the final patched ROM using a custom decoder, but has not been tested with third-party patching tools such as Flips or Lunar IPS.

Do not apply either patch to a previously patched version.

## REQUIREMENTS

The game requires an emulator or flashcart with **SA-1 support**.

Recommended emulators:
- Mesen
- bsnes

## FLASHCART COMPATIBILITY

Compatibility has been tested by players using:
- FXPAK Pro
- SD2SNES with official firmware

**Saving on flashcarts:** After saving, return to a menu and wait a moment before switching off the console. This gives the flashcart time to write the save data to the SD card.

The flashcart's red LED may remain on during gameplay. This behaviour has been observed during testing and has not caused any problems.

## KNOWN ISSUES

- **FXPAK Pro:** Two small white pixels may occasionally appear in the dark area on the left side of the screen in Ghost Valley.
- **Background flicker:** Occasional flickering may occur during particularly demanding moments.
- **Unofficial SD2SNES firmware:** One clone running `sd2snES+` firmware was reported to experience random freezes. This issue has not been reported with official firmware.