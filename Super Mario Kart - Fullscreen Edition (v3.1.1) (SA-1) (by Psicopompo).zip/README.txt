# Super Mario Kart – Fullscreen Edition v3.1.1
**by Psicopompo**

## ABOUT

A full-screen version of Super Mario Kart that brings the single-player races to the entire 256×224 screen.

Two-player mode retains the original split-screen layout.

## WHAT'S NEW IN VERSION 3.1.1

- **Kart size after the finish line with the second camera:** Version 3.1 fixed the size of the kart after finishing a lap without setting a record, but only with camera 1. With camera 2 the kart still looked small. The size is now correct with both cameras.

Everything from versions 3.1 and 3.0 is kept.

## WHAT'S NEW IN VERSION 3.1

Version 3.1 fixes several issues from 3.0, mostly in Time Trial mode:

- **Aligned RETRY menu:** The Time Trial CHANGE COURSE / RETRY menu now appears in its correct position when you retire during a race.
- **Kart size after crossing the finish line:** When you finish a lap without setting a record, the kart now drives away at the correct size, just like in the original game. It used to look tiny because it kept parameters from the full-screen perspective.
- **Ghost aligned with the player:** In full screen, the Time Trial ghost no longer appears a few pixels lower than your kart. Your kart is now positioned using the same projection as every other object and racer, with both cameras.
- **Lower map without displaced lines:** After crossing the finish line, the map on the lower screen no longer shows displaced lines, including after restarting with RETRY. Leftover data that could remain saved from earlier sessions is now cleared.
- **Second camera button:** You can now switch cameras with **X** as well as with Select. X is easier to reach and allows a quick switch. The Y button is still the brake.

Everything from version 3.0 is kept.

## WHAT'S NEW IN VERSION 3.0

- **SA-1 upgrade:** The hack has been migrated from the DSP-1 to the SA-1 chip.
- **Floating minimap:** A new minimap displays the track layout during races.
- **Second camera:** An alternative camera perspective can be selected during gameplay.
- **Improved backgrounds:** Refined sky gradients and graphical improvements.
- **Performance improvements:** Further optimizations and bug fixes.
- **Flashcart compatibility:** Support for FXPAK Pro and SD2SNES.

## PATCHING

Two patches are included:

- `Super Mario Kart - Fullscreen Edition (v3.1.1) (SA-1) (by Psicopompo).bps` (recommended)
- `Super Mario Kart - Fullscreen Edition (v3.1.1) (SA-1) (by Psicopompo).ips`

Apply the patch to a clean, unheadered USA ROM:

**Super Mario Kart (USA).sfc**
- Size: 524,288 bytes
- CRC32: `CD80DB86`

The resulting ROM is 4 MB (4,194,304 bytes) and must match these values:

- CRC32: `EA313F1C`
- SHA-1: `26A746D7177E948409576AA85BF716968F494F0E`
- SNES header checksum: `64CB`
- Checksum complement: `9B34`

The patched ROM already contains the correct header checksum values, so no further correction is needed.

**BPS:** The recommended option. It verifies both the source ROM and the result when applying the patch (with Floating IPS, Flips or beat).

**IPS:** Does not verify the source ROM. It has been verified to produce the exact final ROM using a custom decoder, but has not been tested with third-party patching tools such as Flips or Lunar IPS.

Do not apply either patch to a previously patched version.

## REQUIREMENTS

The game requires an emulator or flashcart with **SA-1 support**.

Recommended emulators:
- Mesen
- bsnes

## FLASHCART COMPATIBILITY

Compatibility has been tested by players using:
- FXPAK Pro
- SD2SNES with official firmware

**Saving on flashcarts:** After saving, return to a menu and wait a moment before switching off the console. This gives the flashcart time to write the save data to the SD card.

The flashcart's red LED may remain on during gameplay. This behaviour has been observed during testing and has not caused any problems.

## KNOWN ISSUES

- **FXPAK Pro:** Two small white pixels may occasionally appear in the dark area on the left side of the screen in Ghost Valley.
- **Background flicker:** Occasional flickering may occur during particularly demanding moments.
- **Unofficial SD2SNES firmware:** One clone running `sd2snes+` firmware was reported to experience random freezes. This issue has not been reported with official firmware.
